<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'cosmos_wordpress');

/** MySQL database username */
define('DB_USER', 'cosmos_user');

/** MySQL database password */
define('DB_PASSWORD', 'Cosmos@123#');

/** MySQL hostname */
define('DB_HOST', '148.66.146.3');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'w;A*)~!=DvNkFnCn1Y<RnK~v;%L86X~40jgPW&YD,l WFQKo0)3Vux76n6!g:!jD');
define('SECURE_AUTH_KEY',  'Xq?C<0>/(k:`}r#kSH*8OMz;qsO65r0y{%^8h%6-Ob;z% *6V,1WSMA>cx7FcId!');
define('LOGGED_IN_KEY',    '9;MgOxH :qMLdwesQ~<_>>WlE&M 5Wdzs_Y_sGo~i;W{)6Vz-~9Uj VGy:UhG^?j');
define('NONCE_KEY',        ',3u@F8Ci=%XVNB}}~T:Q9&*l&s|D:L30aMr+Uo6-T3O>v&oJ/IDCw^F!j_QR;v/,');
define('AUTH_SALT',        '=(nyF;V_r.zxin.2-v^Jypd9/h+fge/HzI7[x/UQ=1ihc$eoH 41gXmdWZtzkUx#');
define('SECURE_AUTH_SALT', 'Mmyp;0#Wwi>g:~/v8[g~/z LDy?d{,wxX=$`P)&dt/}EUDnS+TO0zrKBb<AHON53');
define('LOGGED_IN_SALT',   '*oHBl~3x+p>{(3H7*hz]DXOa;2T` #>zU{ H}|BISXU./rfJU-:n9E:C%V@x3w9D');
define('NONCE_SALT',       'mrqu}=4zZ<.7&$ZNQxdCAyB$J,Q(8T@~FXohtOi!I-N,wk&4Fb6,Mg]s,K@(?K6V');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_cosmos_data_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
